# stock_market_prediction/tests/__init__.py

# 导入测试模块
from .test_utils import TestStockMarketPrediction

# 可选：定义测试包的公共接口
__all__ = [
    "TestStockMarketPrediction",
]
