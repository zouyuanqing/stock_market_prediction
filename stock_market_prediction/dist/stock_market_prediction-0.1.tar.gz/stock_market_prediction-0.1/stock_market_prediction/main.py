from stock_market_prediction.utils import create_gui

def main():
    create_gui()

if __name__ == "__main__":
    main()
